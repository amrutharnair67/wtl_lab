<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class currencyController extends Controller
{

    function index()
    {
        return view ('currency.converter');
    }
    
    function convert()
    {
        return view ('currency.converter');
    }

   
//We can add more currencies like these
            

            }
       

