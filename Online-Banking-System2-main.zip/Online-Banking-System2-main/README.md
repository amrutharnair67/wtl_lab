# Online-Banking-System2
Online Banking system using laravel

## How to run
* clone the project in your local repository.
* Get the project database name from .emv file
* run **php artisan:key generate** in the terminal
* run **php artisan migrate**
* Run **php artisan serve in terminal**
* Go to **localhost:8000/login**
* Now you can preview your project


**Developed By TATIKONDA SAI MURAHARI**